package com.co.certicamara.vista;

import java.util.Scanner;

import com.co.certicamara.modelo.Superficie;
import com.co.certicamara.modelo.Vehiculo;

public class Main {

   public static void main( String [] args ) {
      Superficie superficie = new Superficie();
      Vehiculo vehiculo = new Vehiculo();
      Boolean seguirDesplazando = true;
      Scanner entrada = new Scanner( System.in );

      while ( seguirDesplazando ) {
         vehiculo.desplazarVehiculo( superficie );
         Character respuestaUsuario = null;

         try {
            System.out.println( "Desea seguir desplazando el vehiculo (S) de lo contrario digite cualquier caracter" );
            String entrdaUs = entrada.nextLine();
            respuestaUsuario = new Character( entrdaUs.charAt( 0 ) );
         } catch ( StringIndexOutOfBoundsException e ) {
            System.out.println( "\nRespuesta no válida." );
            e.printStackTrace();
            continue;
         } catch ( Exception e ) {

         }

         if ( ! respuestaUsuario.equals( 'S' ) ) {
            seguirDesplazando = false;
         }

      }

      System.out.println( "\nFin de la aplicacion." );

   }

}
