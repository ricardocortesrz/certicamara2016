package com.co.certicamara.modelo;

import java.util.Scanner;

/**
 * Clase que contiene la superficie de desplazamiento del vehículo.
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public class Superficie {
   private String [] [] superficie;
   private Coordenadas coordenadas;

   /**
    * Se solicitan las dimenciones de la superficie y se crea la superficie con sus coordenadas, se pasa al carro las coordenadas
    * de inicio (0,0).
    */
   public Superficie() {
      solicitarDimensionSuperficie();
      crearSuperficie();
   }

   /**
    * Solicita las dimenciones de la superficie y crea las las coordenadas para dimencionar la superficie.
    */
   private void solicitarDimensionSuperficie() {
      Scanner entrada = new Scanner( System.in );
      StringBuilder peticion = new StringBuilder();
      this.coordenadas = new Coordenadas();
      Boolean isValido = true;
      System.out.println( "Configuración de la superfice:" );

      do {
         peticion = new StringBuilder( "\n1. Digite el numero de filas y columnas que contendrá la superficie," );
         peticion.append( " en formato \\\"fila,columna\\\"\" " );
         peticion.append( "\n\tEjemplo: 10,15" );
         System.out.println( peticion );
         String coordenada = entrada.nextLine();
         isValido = this.coordenadas.validarCoordenadas( coordenada );

      } while ( ! isValido );

// entrada.close();

   }

   /**
    * Llena la superficie con las coordenadas fila, columna y luego imprime la superficie con sus coordenadas.
    */
   private void crearSuperficie() {
      setSuperficie( new String [ coordenadas.getFila() ] [ coordenadas.getColumna() ] );
      for ( int i = coordenadas.getFila() - 1; i >= 0; i-- ) {
         for ( int j = 0; j < coordenadas.getColumna().intValue(); j++ ) {
            superficie [ i ] [ j ] = coordenadas.getFila() - ( i + 1 ) + "," + j;
         }
      }

      System.out.println( "\nSuperficie generada:" );
      for ( int i = 0; i < coordenadas.getFila(); i++ ) {
         for ( int j = 0; j < coordenadas.getColumna(); j++ ) {
            System.out.print( superficie [ i ] [ j ] + "\t" );
         }
         System.out.println();
      }
   }

   /**
    * Realiza la validación el desplazamiento
    * 
    * @param comando
    *           Contiene los comandos de desplazamiento
    * @param vehiculo
    *           Contiene el vehículo
    * @return True o False si se realiza el desplazamiento o no.
    */
   public Boolean realizarDesplazamiento( Comando comando, Vehiculo vehiculo ) {
      Integer posicionFila = vehiculo.getPosicion().getFila();
      Integer posicionColumna = vehiculo.getPosicion().getColumna();// vehiculo.getPosicion().getColumna() + ( columna );
      String coordenada = null;
      String mensajeError = "Se ha detenido el avance por salir de los límites\n";

      // generación de las coordenadas
      switch ( comando.getDireccion() ) {
         case ESTE:
// Se mueve el vehículo 10 a la derecha positivo
            posicionColumna += comando.getCantidadMovimiento();
         break;

         case OESTE:
// Se mueve a la izquierda negativo
            posicionColumna -= comando.getCantidadMovimiento();
         break;

         case NORTE:
// Se mueve hacia arriba negativo
            posicionFila += comando.getCantidadMovimiento();
         break;

         case SUR:
// Se mueve hacia abajo positivo
            posicionFila -= comando.getCantidadMovimiento();
         break;

         default:
            System.out.println( "La dirección dada es incorrecta." );
            return false;
      }

      try {
         coordenada = posicionFila + "," + posicionColumna;

         for ( int i = 0; i < getSuperficie().length; i++ ) {
            for ( int j = 0; j < getSuperficie() [ 0 ].length; j++ ) {
               if ( getSuperficie() [ i ] [ j ].equals( coordenada ) ) {
                  vehiculo.getPosicion().setColumna( posicionColumna );
                  vehiculo.getPosicion().setFila( posicionFila );
                  String comandoUsuario = comando.getCantidadMovimiento() + "," + comando.getDireccion().getDIRECCION();
                  System.out.printf( "El comando aplicado y la posición actual es: %s ; %s\n", comandoUsuario,
                        vehiculo.getPosicion() );
                  return true;
               }
            }
         }

      } catch ( IndexOutOfBoundsException e ) {
         System.out.println( mensajeError );
         return false;
      }

      return false;

   }

   /**
    * Obtiene la superficie donde se desplazará el vehículo
    * 
    * @return La superficie
    */
   public String [] [] getSuperficie() {
      return superficie;
   }

   /**
    * Cambia la superficie donde se desplazará el vehículo
    * 
    * @param La
    *           superficie
    */
   public void setSuperficie( String [] [] superficie ) {
      this.superficie = superficie;
   }

   /**
    * Obtiene las coordenadas
    * 
    * @return Las coordenadas.
    */
   public Coordenadas getCoordenadas() {
      return coordenadas;
   }

   /**
    * Cambia Las coordenadas
    * 
    * @param Las
    *           coordenadas
    */
   public void setCoordenadas( Coordenadas coordenadas ) {
      this.coordenadas = coordenadas;
   }

}
