package com.co.certicamara.modelo;

/**
 * Contiene las cordenadas actuales del vehículo des pues del desplazamiento y lo desplaza.
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public class Vehiculo {

   private Coordenadas posicion;

   public Vehiculo() {
      this.posicion = new Coordenadas();
      this.posicion.setFila( 0 );
      this.posicion.setColumna( 0 );
   }

   /**
    * Realiza el desplazamiento del vehículo por la superficie configurada.
    * 
    * @param superficie
    *           por la cual va a desplazarce el vehículo.
    * @return True o False si se realiza el desplazamiento del vehículo.
    */
   public Boolean desplazarVehiculo( Superficie superficie ) {
      Comando comando = new Comando();
      String [] comandos = comando.solicitarComandos().split( ";" );

      for ( String instruccion : comandos ) {
         if ( comando.validarComando( instruccion ) ) {

            if ( ! superficie.realizarDesplazamiento( comando, this ) ) {
               return false;
            }

         } else {
            return false;

         }
      }
      return true;

   }

   /**
    * coordenadas Obtiene las coordenadas
    * 
    * @return Coordenadas
    */
   public Coordenadas getPosicion() {
      return posicion;
   }

   /**
    * Cambia las coordenadas
    * 
    * @param coordenadas
    */
   public void setPosicion( Coordenadas coordenadas ) {
      this.posicion = coordenadas;
   }

}
