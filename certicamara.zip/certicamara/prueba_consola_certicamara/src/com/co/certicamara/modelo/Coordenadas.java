package com.co.certicamara.modelo;

/**
 * Tiene las cordenadas y valida su formato.
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public class Coordenadas {
   private Integer fila;
   private Integer columna;

   public Coordenadas() {
   }

   /**
    * Realiza la validación de las coordenadas tipo fila,columna que sean enteras y no negativas.
    * 
    * @param coordenadas
    * @return true si es válido el formato de la coordenada
    */
   public Boolean validarCoordenadas( String coordenadas ) {
      String [] valoresCoordenada = coordenadas.split( "," );
      StringBuilder mensajeError = new StringBuilder( "\nEl valor " );
      mensajeError.append( coordenadas );
      mensajeError.append( " tiene un formato inválido." );

      if ( valoresCoordenada.length != 2 ) {
         System.out.println( mensajeError );
         return false;
      }

      try {
         this.fila = new Integer( valoresCoordenada [ 0 ] );
         this.columna = new Integer( valoresCoordenada [ 1 ] );

         if ( fila == null || columna == null || fila < 0 || columna < 0 ) {
            System.out.println( mensajeError );
            return false;
         }

      } catch ( NumberFormatException e ) {
         System.out.println( mensajeError );
         e.printStackTrace();
         return false;
      }
      return true;
   }

   /**
    * Obtiene la fila de la coordenada
    * 
    * @return La fila.
    */
   public Integer getFila() {
      return fila;
   }

   /**
    * Cambia la fila de la coordenada
    * 
    * @param fila
    */
   public void setFila( Integer fila ) {
      this.fila = fila;
   }

   /**
    * Obtiene la columna de la coordenada
    * 
    * @return columna
    */
   public Integer getColumna() {
      return columna;
   }

   /**
    * Cambia la columna de la coordenada
    * 
    * @param columna
    */
   public void setColumna( Integer columna ) {
      this.columna = columna;
   }

   @Override
   public String toString() {
      return getFila() + "," + getColumna();
   }

}
