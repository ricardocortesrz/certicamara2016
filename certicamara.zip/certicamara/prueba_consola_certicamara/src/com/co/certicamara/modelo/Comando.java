package com.co.certicamara.modelo;

import java.util.Scanner;

import com.co.certicamara.controlador.Control;

/**
 * Clase que contiene los comandos del desplazamientos e implementa a Control.
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public class Comando implements Control {
   private Integer cantidadMovimiento;
   private Direccion direccion;

   public Comando() {
   }

   @Override
   public String solicitarComandos() {
      Scanner entrada = new Scanner( System.in );
      StringBuilder salidaPantalla =
            new StringBuilder( "\nPor favor digite los comandos de desplazamiento de la siguiente manera:" );
      salidaPantalla.append( "\n1. En el comando se digita el desplazamiento del vehículo y la dirección " );
      salidaPantalla.append( "\n2. El formato es: cantidad,dirección o un grupo de comandos separados por un \";\" manteniendo" );
      salidaPantalla.append( " el formato ya mencionado. " );
      salidaPantalla.append( "\nLa dirección del comando solo puede contener los siguientes valores:" );
      salidaPantalla.append( "\n\tNorte:N, Sur:S, Este:E, Oeste:O" );
      salidaPantalla.append( "\n\tEjemplo un solo comando: 10,N o grupo de comandos: 56,S;9,O" );
      salidaPantalla.append( "\n\nDigite el comando o grupo de comandos. " );
      System.out.println( salidaPantalla );
      String comandos = entrada.nextLine();
// entrada.close();
      return comandos;

   }

   @Override
   public Boolean validarComando( String comandos ) {
      String mensajeError = "\nError en formato de comando.";
      String [] movimiento = comandos.split( "," );

      if ( movimiento != null && movimiento.length == 2 ) {

         try {
            setCantidadMovimiento( new Integer( movimiento [ 0 ] ) );
            Character direccionAux = movimiento [ 1 ].charAt( 0 );

            for ( Direccion direccion : Direccion.values() ) {
// System.out.println( direccion );
               if ( direccion.getDIRECCION().equals( direccionAux ) ) {
                  setDireccion( direccion );
                  return true;
               }
            }

         } catch ( NumberFormatException nfe ) {
            System.out.println( mensajeError );
            nfe.printStackTrace();
         } catch ( Exception e ) {
            System.out.println( mensajeError );
            e.printStackTrace();
         }

      }

      System.out.println( mensajeError );
      return false;
   }

   /**
    * Obtiene la cantidad a moverse para realizar por el vehículo en una sola dirección
    * 
    * @return La cantidad a moverse en una dirección determinada.
    */
   public Integer getCantidadMovimiento() {
      return cantidadMovimiento;
   }

   /**
    * Cambia la cantidad a moverse para realizar por el vehículo en una sola dirección
    * 
    * @param cantidadMovimiento
    */
   public void setCantidadMovimiento( Integer cantidadMovimiento ) {
      this.cantidadMovimiento = cantidadMovimiento;
   }

   /**
    * Contiene la dirección de un comando
    * 
    * @return La dirección de un comando
    */
   public Direccion getDireccion() {
      return direccion;
   }

   /**
    * Cambia la dirección de un comando
    * 
    * @param direccion
    *           del comando
    */
   public void setDireccion( Direccion direccion ) {
      this.direccion = direccion;
   }

}
