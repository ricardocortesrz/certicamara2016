package com.co.certicamara.modelo;

/**
 * Contiene las diferentes direcciones que puede tomar el vehículo
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public enum Direccion {
   NORTE ( 'N' ), SUR ( 'S' ), ESTE ( 'E' ), OESTE ( 'O' );

   private final Character DIRECCION;

   Direccion( Character dir ) {
      this.DIRECCION = dir;
   }

   /**
    * Retorna el caracter especificado para la dirección.
    * 
    * @return caracter de la dirección.
    */
   public Character getDIRECCION() {
      return DIRECCION;
   }

}
