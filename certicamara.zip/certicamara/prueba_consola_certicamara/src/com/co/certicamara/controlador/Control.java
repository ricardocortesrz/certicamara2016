package com.co.certicamara.controlador;

/**
 * Define los métodos de solicitud y de validación de formato para las coordenadas de desplazamiento del vehículo.
 * 
 * @author Ricardo Cortés Rodríguez
 *
 */
public interface Control {
   /**
    * Solicita por consola las coordenadas de desplazamiento.
    * 
    * @return las coordenadas de desplazamiento del vehículo
    */
   public String solicitarComandos();

   /**
    * Valida las comandos proporcionados por el usuario y retorna una lista de comandos.
    * 
    * @param comandos
    *           Recibe los comandos proporcionados por el usuario.
    * @return TODO
    */
   public Boolean validarComando( String comando );

}
