Instrucciones de instalación del programa por consola:

Versión de JDK 1.7 o superior.

Tener configurada la variable de entorno JAVA_HOME

Descomprimir la carpeta
Colocar el jar que se encuentra en la carpeta x y colocarlo en la ruta que desee.
Luego ejecutar el comando:
java -jar ruta\del\archivo.jar.

Alternativa:
Situarse en la carpeta donde se dejó el archivo .jar y ejecutar el siguiente comando:
java -jar archivo.jar

Listo.


Autor:	Ricardo Cortés Rodríguez
				C.C. 80186058
				Cel: 310-7506775
